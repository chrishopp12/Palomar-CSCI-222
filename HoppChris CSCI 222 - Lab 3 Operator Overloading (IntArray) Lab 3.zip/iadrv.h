// iadrv.h

#ifndef _IADRV_H
#define _IADRV_H

#include "intarray.h"

int main();
void test1();
void test2();
void test3();
void test4();
void test5();
void test6();
void test7();
void test8();
void test9();
void test10();
void test11();
void test12();
void test13();
void test14();
void test15();
void test16();
void test17();
void test18();
void test19();
void test20();
void wait();

#endif

